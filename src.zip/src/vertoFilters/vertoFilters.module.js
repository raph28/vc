(function() {
  'use strict';
  var vertoFilters = angular.module('vertoFilters', []);
})();
