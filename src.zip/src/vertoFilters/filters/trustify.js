(function () {
    'use strict';
  
    angular
    .module('vertoFilters')
    .filter("trustUrl", ['$sce', function ($sce) {
        return function (recordingUrl) {
            return $sce.trustAsResourceUrl(recordingUrl);
        };
      }]);
    })();