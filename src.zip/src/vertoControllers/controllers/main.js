// requirejs.config({
//     baseUrl: 'bower_components',
//     shim: {
//         angular: {
//             exports: 'angular'
//         }
//     },
//     paths: {
//         angular: 'angular/angular',
//         videojs: 'video.js/dist/video-js/video',
//         'vjs-video': '../scripts/directives/vjs.directive'
//     }
// });
// require(['angular', 'vjs-video'], function (angular) {
//     angular.module('app', ['vjs.video'])
//         .controller('MainCtrl', ['$scope', function (scope) {
//             scope.$on('vjsVideoReady', function(e, data) {
//                 //data contains `id`, `vid`, `player` and `controlBar`
//             });
//         }]);
// });


(function() {
    'use strict';
angular.module('vertoControllers')
    .controller('MainCtrl', ['$scope', function ($scope) {
        $scope.mediaToggle = {
            sources: [
                {
                    src: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
                    type: 'video/mp4'
                },
                {
                    src: 'images/happyfit2.webm',
                    type: 'video/webm'
                }
            ],
            tracks: [
                {
                    kind: 'subtitles',
                    label: 'English subtitles',
                    src: 'assets/subtitles.vtt',
                    srclang: 'en',
                    default: true
                }
            ],
            poster: 'images/screen.jpg'
        };
        
        $scope.$on($scope.mediaToggle.sources[0].src, function(mediaToggle){
            console.log($scope.mediaToggle.sources[0].src)
            $scope.$on('vjsVideoMediaChanged', function (e, data) {
                console.log('vjsVideoMediaChanged event was fired');
            });
        });
        //listen for when the vjs-media object changes
        $scope.$on('vjsVideoMediaChanged', function (e, data) {
            console.log('vjsVideoMediaChanged event was fired');
        });
    }]);
})();