(function() {
  'use strict';

  var vertoControllers = angular.module('vertoControllers', [
    'ui.bootstrap',
    'vertoService',
    'storageService',
    'ui.gravatar',
    'vjs.video',
  ]);

})();
