(function() {
  'use strict';
  var vertoDirectives = angular.module('vertoDirectives', []);
})();
