(function() {
  'use strict';
  var vertoService = angular.module('vertoService', []);
})();
